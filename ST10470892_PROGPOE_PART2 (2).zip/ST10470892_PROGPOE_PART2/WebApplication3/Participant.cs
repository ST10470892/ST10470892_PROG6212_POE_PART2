﻿namespace RaceDay.API.Data
{
    public class Participant
    {
    }
}