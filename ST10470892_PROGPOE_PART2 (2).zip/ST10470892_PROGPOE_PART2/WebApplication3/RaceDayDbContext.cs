﻿
using Microsoft.EntityFrameworkCore;

namespace RaceDay.API.Data
{
    public class RaceDayDbContext : DbContext
    {
        public RaceDayDbContext(
            DbContextOptions<RaceDayDbContext> options)
            : base(options)
        {
        }

        public DbSet<Participant> Participants { get; set; }
    }
}
